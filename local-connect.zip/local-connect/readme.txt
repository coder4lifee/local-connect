Welcome!

instructions-

Open program when server is running (failed = server offline) (success = server online)

You will connect to server from there

